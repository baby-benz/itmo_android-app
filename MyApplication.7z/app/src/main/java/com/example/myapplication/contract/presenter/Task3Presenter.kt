package com.example.myapplication.contract.presenter

import com.example.myapplication.contract.Task3Contract

class Task3Presenter(
    private var view: Task3Contract.View?,
    private val model: Task3Contract.Model
) : Task3Contract.Presenter {
    override fun onProductListLoading() {
        val products = model.getProducts()
        if (products.isEmpty()) {
            view?.hideEmptyListTextView()
        } else {
            view?.setListAdapter(products)
        }
    }

    override fun onDestroy() {
        this.view = null
    }
}