package com.example.myapplication.contract

interface IncrementerContract {
    interface View {
        fun updateIncrementerText(text: String)
    }

    interface Presenter {
        fun onIncrementButtonPressed()
        fun onDecrementButtonPressed()
        fun onDestroy()
    }

    interface Model {
        fun updateNum(value: Int)
        fun getNum(): Int
    }
}