package com.example.myapplication.fragments

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import com.example.myapplication.R
import com.example.myapplication.contract.Task3Contract.Model.Product


class ProductsAdapter(@NonNull context: Context, productList: List<Product>) : ArrayAdapter<Product>(context, 0, productList) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var currentItemView = convertView

        if (currentItemView == null) {
            currentItemView =
                LayoutInflater.from(context).inflate(R.layout.task3_list_element, parent, false)
        }

        val currentProduct = getItem(position)

        currentItemView?.findViewById<ImageView>(R.id.image)?.setImageResource(R.drawable.ic_skull) // TODO: вставлять реальную картинку
        //productsImage?.setImageResource(currentProduct.getNumbersImageId())

        // then according to the position of the view assign the desired TextView 1 for the same
        currentItemView?.findViewById<TextView>(R.id.title)?.text = currentProduct?.name

        // then according to the position of the view assign the desired TextView 2 for the same
        currentItemView?.findViewById<TextView>(R.id.price)?.text = currentProduct?.price.toString()

        // then return the recyclable view
        return currentItemView!!
    }
}