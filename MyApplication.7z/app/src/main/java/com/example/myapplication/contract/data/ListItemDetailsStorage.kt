package com.example.myapplication.contract.data

import com.example.myapplication.contract.ListItemDetailsContract

private const val FIBONACCI_MAX_INT_VALUE = 1836311903

class Task1DetailedModel(state: ListItemDetailsContract.State) :
    ListItemDetailsContract.Model {
    private var natural: Int = state.natural
    private var fibonacci: Int = state.fibonacci
    private var nextFibonacci: Int = state.nextFibonacci
    private var collatz: Int = state.collatz

    override fun nextNatural(): Int {
        return if (natural < Int.MAX_VALUE) {
            natural++
            natural
        } else {
            throw RuntimeException()
        }
    }

    override fun nextFibonacci(): Int {
        return if (fibonacci < FIBONACCI_MAX_INT_VALUE) {
            val tmp = fibonacci + nextFibonacci
            fibonacci = nextFibonacci
            nextFibonacci = tmp
            fibonacci
        } else {
            throw RuntimeException()
        }
    }

    override fun nextCollatz(): Int {
        return if (collatz != 1) {
            if (collatz and 1 == 0) {
                collatz /= 2
            } else {
                collatz = collatz * 3 + 1
            }
            collatz
        } else {
            throw RuntimeException()
        }
    }

    override fun curState(): ListItemDetailsContract.State {
        return ListItemDetailsContract.State(natural, fibonacci, nextFibonacci, collatz)
    }
}