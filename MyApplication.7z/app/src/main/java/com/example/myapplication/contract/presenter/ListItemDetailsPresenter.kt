package com.example.myapplication.contract.presenter

import com.example.myapplication.contract.ListItemDetailsContract

class ListItemDetailsPresenter(
    private var view: ListItemDetailsContract.View?,
    private val model: ListItemDetailsContract.Model
) : ListItemDetailsContract.Presenter {
    override fun onNaturalButtonPressed() {
        try {
            view?.displayNatural(model.nextNatural())
        } catch (ex: RuntimeException) {
            view?.showMaxNumberErrorToast()
        }
    }

    override fun onFibonacciButtonPressed() {
        try {
            view?.displayFibonacci(model.nextFibonacci())
        } catch (ex: RuntimeException) {
            view?.showMaxNumberErrorToast()
        }
    }

    override fun onCollatzButtonPressed() {
        try {
            view?.displayCollatz(model.nextCollatz())
        } catch (ex: RuntimeException) {
            view?.showLastCollatzMemberErrorToast()
        }
    }

    override fun curState(): ListItemDetailsContract.State {
        return model.curState()
    }

    override fun onDestroy() {
        this.view = null
    }
}