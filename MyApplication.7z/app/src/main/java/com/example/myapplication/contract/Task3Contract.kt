package com.example.myapplication.contract

interface Task3Contract {
    interface View {
        fun showEmptyListTextView()
        fun hideEmptyListTextView()
        fun setListAdapter(products: List<Model.Product>)
    }

    interface Presenter {
        fun onProductListLoading()
        fun onDestroy()
    }

    interface Model {
        data class Product(
            val id: String,
            val name: String,
            val price: Double,
            val producerId: String,
            val supplierId: String
        )

        fun getProducts(): List<Product>
        fun getProductsPaginated(): List<Product>
        fun close()
    }
}