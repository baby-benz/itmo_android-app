package com.example.myapplication.contract.data

import io.ktor.client.*
import com.example.myapplication.contract.Task3Contract
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.http.*
import kotlinx.coroutines.runBlocking
import com.example.myapplication.contract.Task3Contract.Model.Product
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*

class Task3Storage : Task3Contract.Model {
    override fun getProducts(): List<Product> {
        return runBlocking {
            client.get("products").body() as List<Product>
        }
    }

    override fun getProductsPaginated(): List<Product> {
        TODO("Not yet implemented")
    }

    override fun close() = client.close()

    private companion object {
        val client = HttpClient(CIO) {
            //install(Logging)
            install(ContentNegotiation)
            install(HttpTimeout) {
                requestTimeoutMillis = 4000L
                connectTimeoutMillis = 4000L
                socketTimeoutMillis = 4000L
            }
            defaultRequest {
                url {
                    protocol = URLProtocol.HTTP
                    host = "192.168.2.114:8080"
                }
            }
        }
    }
}