package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import com.example.myapplication.contract.Task3Contract
import com.example.myapplication.contract.Task3Contract.Model.Product
import com.example.myapplication.contract.data.Task3Storage
import com.example.myapplication.contract.presenter.Task3Presenter
import com.example.myapplication.databinding.FragmentTask3Binding


class Task3Fragment : Fragment(), Task3Contract.View {
    /*private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(
            Barcode.FORMAT_QR_CODE,
            Barcode.FORMAT_AZTEC)
        .build()*/
    private val presenter: Task3Contract.Presenter = Task3Presenter(this, Task3Storage())
    private lateinit var binding: FragmentTask3Binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTask3Binding.inflate(inflater, container, false)
        presenter.onProductListLoading()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.searchBar.doAfterTextChanged {
            // TODO: implement filter
        }

        binding.barcodeScanButton.setOnClickListener {
            // TODO: implement scanner
        }
    }

    override fun showEmptyListTextView() {
        binding.emptyListTextView.visibility = View.VISIBLE
    }

    override fun hideEmptyListTextView() {
        binding.emptyListTextView.visibility = View.GONE
    }

    override fun setListAdapter(products: List<Product>) {
        binding.productsListView.adapter = ProductsAdapter(requireContext(), products)
    }
}