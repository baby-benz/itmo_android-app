package com.example.myapplication.contract.presenter

import com.example.myapplication.contract.IncrementerContract
import com.example.myapplication.contract.data.IncrementerPersistentStorageModel

class IncrementerPresenter(
    private var view: IncrementerContract.View?,
    private val model: IncrementerPersistentStorageModel
) : IncrementerContract.Presenter {
    init {
        view?.updateIncrementerText(model.getNum().toString())
    }

    override fun onIncrementButtonPressed() {
        var num = model.getNum()
        if (num < 100) {
            num++
            model.updateNum(num)
            view?.updateIncrementerText(num.toString())
        }
    }

    override fun onDecrementButtonPressed() {
        var num = model.getNum()
        if (num > 0) {
            num--
            model.updateNum(num)
            view?.updateIncrementerText(num.toString())
        }
    }

    override fun onDestroy() {
        view = null
    }
}