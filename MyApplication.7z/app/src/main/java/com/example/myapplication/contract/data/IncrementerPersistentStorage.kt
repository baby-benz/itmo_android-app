package com.example.myapplication.contract.data

import android.content.SharedPreferences
import com.example.myapplication.contract.IncrementerContract

private const val SHARED_PREFERENCES_NUM_KEY = "Num"
private const val DEFAULT_NUM = 0

class IncrementerPersistentStorageModel(private val sharedPrefs: SharedPreferences) :
    IncrementerContract.Model {
    override fun updateNum(value: Int) {
        sharedPrefs.edit().putInt(SHARED_PREFERENCES_NUM_KEY, value)?.apply()
    }

    override fun getNum(): Int {
        return sharedPrefs.getInt(SHARED_PREFERENCES_NUM_KEY, DEFAULT_NUM)
    }
}